import React from 'react';
import { PageTemplate, PolyBackground, BgColor, CoinMain, Card } from 'components';
import {HeaderContainer, CoinMainContainer, SocketSubscriber} from 'containers';
import styles from './HomePage.scss';
import classNames from 'classnames/bind';
import IntroQuestionContainer from 'containers/IntroQuestionContainer';
import MoreIcon from 'react-icons/lib/md/more-vert';
import { Link } from 'react-router-dom';
import TrophyIcon from 'react-icons/lib/fa/trophy';
import GithubIcon from 'react-icons/lib/go/mark-github';
import EmailIcon from 'react-icons/lib/md/email';
import { Helmet } from 'react-helmet';

const cx = classNames.bind(styles);


const HomePage = () => {
  return (
    <PageTemplate 
      header={<HeaderContainer/>}>
      <Helmet>
        <title>Binanace - Virtual currency mock exchange</title>
        <meta name="keywords" content="Virtual currency, cryptocurrency, simulation, trading, exchange, Bitcoin, Ethereum, BTC, ETH"/>
        <meta name="description" content="Cryptocurrency / cryptocurrency simulation exchange Binance, can you really make a profit in the cryptocurrency market? Find out through trading."/>
      </Helmet>
      <SocketSubscriber channel="TICKER"/>
      <PolyBackground home>
        <IntroQuestionContainer/>
      </PolyBackground>
      <BgColor color="#f6f6f6"/>
      <div className={cx('block', 'responsive')}>
        <h2>In non binance, the current total <b>69</b>support 20 cryptocurrency.</h2>
        <CoinMainContainer/>
        <div className={cx('more')}>
          <Link className={cx('more-button')} to="/trade">
            see more on Exchange
          </Link>
        </div>
      </div>
      <div className={cx('third')}>
        <div className={cx('responsive', 'grid')}>
          <Link to="/ranking" className={cx('column')}>
            <TrophyIcon/>
            <div className={cx('description')}>
              <h3>Ranking system</h3>
              <p>compete with other for yield <br/>and check out other people trading strategy</p>
            </div>
          </Link>
          <a className={cx('column')} href="https://github.com/ahsansiddiqi-113" target="_blank" rel="noopener noreferrer">
            <GithubIcon/>
            <div className={cx('description')}>
              <h3>open source</h3>
              <p>Binance is not an open source Project <br/>Pull Request is not available.</p>
            </div>
          </a>
        </div>
        <div className={cx('my-message', 'responsive')}>
          <div>
          Prizes are funded through in-page advertising costs.<br/>
          The more often you use this service, the higher your winnings will be
          </div>
        </div>
      </div>
      <div className={cx('footer')}>
        <div className={cx('email')}>
          <EmailIcon/> support
        </div>
        <div className={cx('copyright')}>
          Copyright © 2017 Binance
        </div>
        <div className={cx('copyright')}>
        <Link to="/terms">Privacy Statement</Link>
      </div>
      </div>
    </PageTemplate>
  );
};

export default HomePage;