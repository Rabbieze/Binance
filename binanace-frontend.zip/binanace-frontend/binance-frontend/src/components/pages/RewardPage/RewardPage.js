import React from 'react';
import styles from './RewardPage.scss';
import classNames from 'classnames/bind';
import { PageTemplate } from 'components';
import { HeaderContainer, RewardWalletFormContainer } from 'containers';

const cx = classNames.bind(styles);

const RewardPage = () => (
  <PageTemplate header={<HeaderContainer solid/>} padding responsive>
    <div className={cx('reward-page')}>
      <h1>Set up your winnings wallet</h1>
      <div className={cx('description')}>
        <p>Every month, the prize money is paid in Ripple (XRP) to the first place in the monthly profit ranking</p>
        <p>Enter the Ripple wallet information to receive rewards.</p>
      </div>
      <div className={cx('form')}>
        <RewardWalletFormContainer/>
      </div>
    </div>
  </PageTemplate>
);

export default RewardPage;