import React from 'react';
import styles from './ReportPage.scss';
import classNames from 'classnames/bind';
import { PageTemplate, Card } from 'components';
import { HeaderContainer, ReportContainer, SocketSubscriber } from 'containers';
import { Helmet } from 'react-helmet';


const cx = classNames.bind(styles);

const ReportPage = ({match}) => {
  const { displayName } = match.params;

  return (
    <PageTemplate header={<HeaderContainer solid/>} padding>
      <Helmet>
        <title>{`${displayName}Report by:: Binance `}</title>
        <meta name="description" content={`${displayName}exchange report`}/>
      </Helmet>
      <div className={cx('block')}>
      </div>
      <Card className={cx('ranking-box')}>
        <h1>{displayName}Report By</h1>
        <hr/>
        <ReportContainer displayName={displayName}/>
      </Card>
      <SocketSubscriber channel="TICKER"/>
    </PageTemplate>
  );
}

export default ReportPage;