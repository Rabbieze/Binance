import React from 'react';
import styles from './RankingPage.scss';
import classNames from 'classnames/bind';
import { PageTemplate, Card, PolyBackground, ResponsiveAd } from 'components';
import { HeaderContainer, RankingContainer } from 'containers';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';

const cx = classNames.bind(styles);

const RankingPage = ({match}) => {
  const { type } = match.params;

  return (
    <PageTemplate header={<HeaderContainer solid/>} padding>
      <Helmet>
        <title>Ranking :: Binance</title>
        <meta name="description" content="Ranking of simulated trading returns by users"/>
      </Helmet>
      <div className={cx('block')}>
      </div>
      <Card className={cx('ranking-box')}>
        <div className={cx('ads-area')}>
          <ResponsiveAd/>
        </div>
        <h1>Yield Ranking</h1>
        <div className={cx('description')}>
        Yields are calculated based on USD.
          <br/>Ranking is done every hour.
          <br/>Prize money will be given to the first place in the monthly profit ranking!
          <br/>
          <br/>
If abusing is found, it can be rolled back.
        </div>
        <hr/>
        <div className={cx('type-selector')}>
          <Link to="/ranking/monthly" className={cx('type', {
            active: !type || type === 'monthly'
          })}>
            Monthly Yield
          </Link>
          <Link to="/ranking/total" className={cx('type', {
            active: type === 'total'
          })}>
            Overall Yield
          </Link>
        </div>
        <RankingContainer type={type}/>
      </Card>
    </PageTemplate>
  );
}

export default RankingPage;