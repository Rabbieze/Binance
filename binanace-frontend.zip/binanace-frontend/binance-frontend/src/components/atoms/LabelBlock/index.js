import LabelBlock from './LabelBlock.js'

export default LabelBlock
