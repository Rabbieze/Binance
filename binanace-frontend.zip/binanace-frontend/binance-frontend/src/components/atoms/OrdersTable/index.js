import OrdersTable from './OrdersTable.js'

export default OrdersTable
