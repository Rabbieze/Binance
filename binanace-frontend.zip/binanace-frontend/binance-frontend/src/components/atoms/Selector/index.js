import Selector from './Selector.js'

export default Selector
