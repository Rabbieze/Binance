import SortReverser from './SortReverser.js'

export default SortReverser
