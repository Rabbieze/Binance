import React from 'react';
import styles from './IntroQuestion.scss';
import classNames from 'classnames/bind';

const cx = classNames.bind(styles);

const IntroQuestion = ({onClick}) => (
  <div className={cx('question')}>          
  <div>
    <h1>
    challenge! Cryptocurrency trading!<br/>
      <b>300 ripple</b> shoot!
    </h1>
    <p>
    Based on real-time data from real exchanges
      <br/>Try Trading!
      <br/><br/>Prize money will be paid to the first place in the monthly yield ranking.
    </p>
  </div>
  <div className={cx('button')} onClick={onClick}>
    Start Trading
  </div>
</div>
);

export default IntroQuestion;