import RateInfoCard from './RateInfoCard.js'

export default RateInfoCard
