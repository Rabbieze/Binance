import BitcoinInfoCard from './BitcoinInfoCard.js'

export default BitcoinInfoCard
