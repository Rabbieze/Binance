import CurrentInfo from './CurrentInfo.js'

export default CurrentInfo
