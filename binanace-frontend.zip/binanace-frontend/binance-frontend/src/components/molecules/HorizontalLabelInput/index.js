import HorizontalLabelInput from './HorizontalLabelInput.js'

export default HorizontalLabelInput
